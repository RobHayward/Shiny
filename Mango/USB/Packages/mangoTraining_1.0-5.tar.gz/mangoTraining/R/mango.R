#' @name mangoTraining-package
#' @title mangoTraining
#' @aliases mangoTraining mangoTraining-package
#' @description A few data frames containing typical pharmaceutical data
#' @docType package
#' @details 
#' \tabular{ll}{
#' Package: \tab mangoTraining\cr
#' Type: \tab Package\cr
#' Version: \tab 1.3\cr
#' Date: \tab 17-05-2013\cr
#' License: \tab GNU\cr
#' LazyLoad: \tab yes\cr
#' }
#' Datasets designed to be used in conjunction with Mango Solutions' training materials
#' @author Mango Solutions
#'
#' Maintainer: Mango Solutions \email{trgsupport@@mango-solutions.com}
NULL




#' @name demoData
#' @title demoData
#' @description Demographics data
#' @docType data
#' @usage data(demoData)
#' @format  A data frame with 33 observations on the following 7 variables.
#'  \describe{
#'    \item{\code{Subject}}{a numeric vector}
#'    \item{\code{Sex}}{a factor with levels \code{F} \code{M}}
#'    \item{\code{Age}}{a numeric vector}
#'    \item{\code{Weight}}{a numeric vector}
#'    \item{\code{Height}}{a numeric vector}
#'    \item{\code{BMI}}{a numeric vector}
#'    \item{\code{Smokes}}{a factor with levels \code{No} \code{Yes}}
#'  }
#' @keywords datasets
NULL




#' @name emaxData
#' @title emaxData
#' @description Data that can be used to fit or plot Emax models
#' @docType data
#' @usage data(emaxData)
#' @format   A data frame with 64 observations on the following 6 variables.
#'  \describe{
#'    \item{\code{Subject}}{a numeric vector}
#'    \item{\code{Dose}}{a numeric vector}
#'    \item{\code{E}}{a numeric vector}
#'    \item{\code{Gender}}{a numeric vector}
#'    \item{\code{Age}}{a numeric vector}
#'    \item{\code{Weight}}{a numeric vector}
#'  }
#' @keywords datasets
NULL


#' @name missingPk
#' @title missingPk
#' @description Clinical trial data
#' @docType data
#' @usage data(missingPk)
#' @format   A data frame with 165 observations on the following 4 variables.
#' \describe{
#'   \item{\code{Subject}}{a numeric vector}
#'   \item{\code{Dose}}{a numeric vector}
#'   \item{\code{Time}}{a numeric vector}
#'  \item{\code{Conc}}{a numeric vector}
#'  }
#' @keywords datasets
NULL

#' @name pkData
#' @title pkData
#' @description Typical PK data
#' @docType data
#' @usage data(pkData)
#' @format   A data frame with 165 observations on the following 4 variables.
#'  \describe{
#'    \item{\code{Subject}}{a numeric vector}
#'    \item{\code{Dose}}{a numeric vector}
#'    \item{\code{Time}}{a numeric vector}
#'    \item{\code{Conc}}{a numeric vector}
#'  }
#' @keywords datasets
NULL




#' @name runData
#' @title runData
#' @description An example of NONMEM run data
#' @docType data
#' @usage data(runData)
#' @format   A data frame with 73 observations on the following 10 variables.
#' \describe{
#'    \item{\code{ID}}{a numeric vector}
#'    \item{\code{DAY}}{a numeric vector}
#'    \item{\code{CL}}{a numeric vector}
#'    \item{\code{V}}{a numeric vector}
#'    \item{\code{WT}}{a numeric vector}
#'    \item{\code{DV}}{a numeric vector}
#'    \item{\code{IPRE}}{a numeric vector}
#'    \item{\code{PRED}}{a numeric vector}
#'    \item{\code{RES}}{a numeric vector}
#'    \item{\code{WRES}}{a numeric vector}
#'  }
#' @keywords datasets
NULL


#' @name tubeData
#' @title tubeData
#' @description London Tube data
#' @docType data
#' @usage data(tubeData)
#' @format  A data frame with 1050 observations on the following 9 variables.
#'  \describe{
#'    \item{\code{Line}}{a factor with 10 levels, for each tube line}
#'    \item{\code{Month}}{a numeric vector}
#'    \item{\code{Scheduled}}{a numeric vector}
#'    \item{\code{Excess}}{a numeric vector}
#'    \item{\code{TOTAL}}{a numeric vector}
#'    \item{\code{Opened}}{a numeric vector}
#'    \item{\code{Length}}{a numeric vector}
#'    \item{\code{Type}}{A numeric vector}
#'    \item{\code{Stations}}{A numeric vector}
#'  }
#' @keywords datasets
NULL


#' @name xpData
#' @title xpData
#' @description Typical NONMEM data
#' @docType data
#' @usage data(xpData)
#' @format   A data frame with 1061 observations on the following 23 variables.
#' \describe{
#'    \item{\code{ID}}{a numeric vector}
#'    \item{\code{SEX}}{a numeric vector}
#'    \item{\code{RACE}}{a numeric vector}
#'    \item{\code{SMOK}}{a numeric vector}
#'    \item{\code{HCTZ}}{a numeric vector}
#'    \item{\code{PROP}}{a numeric vector}
#'    \item{\code{CON}}{a numeric vector}
#'    \item{\code{DV}}{a numeric vector}
#'    \item{\code{PRED}}{a numeric vector}
#'    \item{\code{RES}}{a numeric vector}
#'    \item{\code{WRES}}{a numeric vector}
#'    \item{\code{AGE}}{a numeric vector}
#'    \item{\code{HT}}{a numeric vector}
#'    \item{\code{WT}}{a numeric vector}
#'    \item{\code{SECR}}{a numeric vector}
#'    \item{\code{OCC}}{a numeric vector}
#'    \item{\code{TIME}}{a numeric vector}
#'    \item{\code{IPRE}}{a numeric vector}
#'    \item{\code{IWRE}}{a numeric vector}
#'    \item{\code{SID}}{a numeric vector}
#'    \item{\code{CL}}{a numeric vector}
#'    \item{\code{V}}{a numeric vector}
#'    \item{\code{KA}}{a numeric vector}
#'  }
#' @keywords datasets
NULL

